#!/bin/bash
declare -a refr=("1.31" "1.70" "2.0")
declare -a refi=("0.0" "0.0" "0.2") 
declare -a x=("3" "1" "0.3") 

declare -a shapes=("grs2" "grs2fine")
END=50
base="./scadyn"
fold="shapes/GRS"

#for shape in "${shapes[@]}"; do
#	for j in $(seq 1 $END); do
#		mesh=" -mesh shapes/GRS/$shape.h5"
#		T=" -T shapes/GRS/T$shape.h5"
#		lg=" -log out/log_$shape""_$j"
#		comm="$base$mesh$T$lg"
#		eval "$comm"
#	done
#done

eval "cd out/"
eval "pwd"
for shape in "${shapes[@]}"; do
	for j in $(seq 1 $END); do
		lg=" -l log_$shape""_$j"
		comm="python evo.py$lg"
		eval "$comm"
	done
done

eval "cd .."

#for k in 1 2 3 4 5; do
#	for i in 1 2 3; do
#		wb=" -wb "$i
#		for ri in 0 1 2; do
#		 fixrefr=" -refr "${refr[$ri]}""
#		 fixrefi=" -refi ${refi[$ri]}"
#		 ref="${refr[$ri]}-${refi[$ri]}"
#		 
#		 for shape in "${shapes[@]}"; do
#		  for j in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
#		   mesh=" -mesh $fold/$shape/$shape""_tet$j.h5"
#		   T=" -T $fold/$shape/T-$shape$j-$ref.h5"
#		   log=" -log out/$k""log-$shape$j-$ref-x-"${x[$i-1]}
#		   #log=" -log out/log-$shape$j-$ref-x"${x[$i]}
#		   mueller=" -mueller out/mueller-$shape$j-$ref-x"${x[$i]}
#		   comm=$base$mesh$T$log$fixrefr$fixrefi$mueller$wb
#		   repl="sed -i '28 s| .* | "$comm" |' script.sh"
#		   
#		   eval "$comm"
#	#    echo "$repl"
#	#    echo "sbatch script.sh"
#		  done
#		 done
#		done
#	done
#done

#for i in 1 2 3; do
#	wb=" -wb "$i
#	for ri in 0 1 2; do
#	 fixrefr=" -refr "${refr[$ri]}""
#	 fixrefi=" -refi ${refi[$ri]}"
#	 ref="${refr[$ri]}-${refi[$ri]}"
#	 
#	 for shape in "${shapes[@]}"; do
#	  for j in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
#	   mesh=" -mesh $fold/$shape/$shape""_tet$j.h5"
#	   T=" -T $fold/$shape/T-$shape$j-$ref.h5"
#	   #log=" -log out/$k""log-$shape$j-$ref-x-"${x[$i-1]}
#	   log=" -log out/log-$shape$j-$ref-x"${x[$i]}
#	   mueller=" -mueller out/mueller-$shape$j-$ref-x"${x[$i]}
#	   comm=$base$mesh$T$log$fixrefr$fixrefi$mueller$wb
#	   repl="sed -i '28 s| .* | "$comm" |' script.sh"
#	   
#	   eval "$comm"
##    echo "$repl"
##    echo "sbatch script.sh"
#	  done
#	 done
#	done
#done
