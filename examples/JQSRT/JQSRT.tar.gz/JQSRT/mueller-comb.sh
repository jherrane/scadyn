#!/bin/bash
declare -a refr=("1.31" "1.70" "2.0")
declare -a refi=("0.0" "0.0" "0.2") 
declare -a x=("3" "1" "0.3") 
declare -a shapes=("ell" "ob" "pro" "sph")

base="python mueller.py"
fold="out"
mode=""
outname="mueller-"

while getopts p:m: option
do
 case "${option}"
 in
 p) fold=${OPTARG};;
 m) mode="-"${OPTARG};;
 esac
done

BEGIN=1
END=15
a=0

for i in 1 2 3; do
	eval "$fixx"
	for ri in 0 1 2; do
		ref="${refr[$ri]}-${refi[$ri]}"

		for shape in "${shapes[@]}"; do
			path=" -p $fold"
			in=" -i mueller-$shape""0-$ref-x-"${x[$i-1]}$mode
			
			out1=" -o $outname$shape""0-$ref-x-"${x[$i-1]}
			comm1=$base$path$in$out1
			
			out2=" -o mueller_all0-$ref-x-"${x[$i-1]}
			comm2=$base$path$in$out2
			eval "$comm1"
			eval "$comm2"
			for j in $(seq $BEGIN $END); do
				path=" -p $fold"
				in=" -i mueller-$shape$j-$ref-x-"${x[$i-1]}$mode
				
				out1=" -o $outname$shape-$ref-x-"${x[$i-1]}
				comm1=$base$path$in$out1
				
				out2=" -o mueller_all-$ref-x-"${x[$i-1]}
				comm2=$base$path$in$out2
				
				eval "$comm1"
				eval "$comm2"
				let "a += 1"
				echo "i = $a"
			done
		done
	done
done

for k in 1 2 3 4 5; do
	for i in 1 2 3; do
		eval "$fixx"
		for ri in 0 1 2; do
			ref="${refr[$ri]}-${refi[$ri]}"

			for shape in "${shapes[@]}"; do
				path=" -p $fold"
				in=" -i mueller-$shape""0-$ref-x-"${x[$i-1]}$mode
			
				out1=" -o $outname$shape""0-$ref-x-"${x[$i-1]}
				comm1=$base$path$in$out1
			
				out2=" -o mueller_all0-$ref-x-"${x[$i-1]}
				comm2=$base$path$in$out2
				eval "$comm1"
				eval "$comm2"
				for j in $(seq $BEGIN $END); do
					path=" -p $fold"
					in=" -i mueller-$k$shape$j-$ref-x-"${x[$i-1]}$mode
				
					out1=" -o $outname$shape-$ref-x-"${x[$i-1]}
					comm1=$base$path$in$out1
				
					out2=" -o mueller_all-$ref-x-"${x[$i-1]}
					comm2=$base$path$in$out2
				
					eval "$comm1"
					eval "$comm2"
					let "a += 1"
					echo "i = $a"
				done
			done
		done
	done
done
