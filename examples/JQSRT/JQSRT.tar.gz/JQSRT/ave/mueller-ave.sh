#!/bin/bash
declare -a refr=("1.31" "1.70" "2.0")
declare -a refi=("0.0" "0.0" "0.2") 
declare -a x=("3" "1" "0.3") 

declare -a shapes=("ell" "ob" "pro" "sph")
END=15
base="python mueller-ave.py"
fold="out"
outname="mueller-"

while getopts p: option
do
 case "${option}"
 in
 p) fold=${OPTARG};;
 esac
done

a=0

for i in 1 2 3; do
	eval "$fixx"
	for ri in 0 1 2; do
		ref="${refr[$ri]}-${refi[$ri]}"

		for shape in "${shapes[@]}"; do
			for j in $(seq 0 0); do
				in=" -i mueller-$shape$j-$ref-x-"${x[$i-1]}"-ave"
				out=" -o $outname$shape"0"-$ref-x-"${x[$i-1]}
				path=" -p $fold"
				comm=$base$path$in$out
				
#				echo "$comm"
				eval "$comm"
				let "a += 1"
				echo "i = $a"
			done
		done
	done
done

for i in 1 2 3; do
	eval "$fixx"
	for ri in 0 1 2; do
		ref="${refr[$ri]}-${refi[$ri]}"

		for shape in "${shapes[@]}"; do
			for j in $(seq 1 $END); do
				in=" -i mueller-$shape$j-$ref-x-"${x[$i-1]}"-ave"
				out=" -o $outname$shape-$ref-x-"${x[$i-1]}
				path=" -p $fold"
				comm=$base$path$in$out
				
#				echo "$comm"
				eval "$comm"
				let "a += 1"
				echo "i = $a"
			done
		done
	done
done


