#!/bin/bash
declare -a refr=("1.31" "1.70" "2.0")
declare -a refi=("0.0" "0.0" "0.2") 
declare -a x=("3" "1" "0.3") 

declare -a shapes=("ell" "ob" "pro" "sph")
base="python mueller-ave.py"
fold="mueller-ave"
outname="mueller-"
END=15

while getopts p: option
do
 case "${option}"
 in
 p) fold=${OPTARG};;
 esac
done

for i in 1 2 3; do
	eval "$fixx"
	for ri in 0 1 2; do
		ref="${refr[$ri]}-${refi[$ri]}"

		for shape in "${shapes[@]}"; do
			for k in $(seq 0 0); do
				in=" -i $outname$shape$k-$ref-x-"${x[$i-1]}"-ave"
				out=" -o mueller_all0-$ref-x-"${x[$i-1]}
				path=" -p $fold"
				comm=$base$path$in$out

				eval "$comm"
			done
		done
	done
done

for i in 1 2 3; do
	eval "$fixx"
	for ri in 0 1 2; do
		ref="${refr[$ri]}-${refi[$ri]}"

		for shape in "${shapes[@]}"; do
			for k in $(seq 1 $END); do
				in=" -i $outname$shape$k-$ref-x-"${x[$i-1]}"-ave"
				out=" -o mueller_all-$ref-x-"${x[$i-1]}
				path=" -p $fold"
				comm=$base$path$in$out

				eval "$comm"
			done
		done
	done
done
