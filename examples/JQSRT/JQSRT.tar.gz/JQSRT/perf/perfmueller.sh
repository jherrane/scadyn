#!/bin/bash
declare -a refr=("1.31" "1.70" "2.0")
declare -a refi=("0.0" "0.0" "0.2") 
declare -a xs=("3" "1" "0.3") 

declare -a shapes=("ell" "ob" "pro" "sph")
END=15
base="./scadyn"
fold="data"
seed=0

for i in 1 2 3; do
	wb=" -wb "$i
	x=${xs[$i-1]} 
	for ri in 0 1 2; do
		fixrefr=" -refr "${refr[$ri]}""
		fixrefi=" -refi ${refi[$ri]}"
		ref="${refr[$ri]}-${refi[$ri]}"

		for shape in "${shapes[@]}"; do
			for j in $(seq 0 $END); do
				mesh=" -mesh $fold/$shape""_tet$j.h5"
				T=" -T $fold/T/T-$shape$j-$ref.h5"
				mueller=" -mueller out/mueller-$shape$j-$ref-x-"$x
				comm=$base$mesh$T$fixrefr$fixrefi$mueller$wb
				repl="sed -i '9s|.*|"$comm"|' script.sh"
				eval "$comm"
			done
		done
	done
done
