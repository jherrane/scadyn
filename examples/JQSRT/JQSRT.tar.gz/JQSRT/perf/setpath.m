function path = setpath(str)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
path = [str,'/'];

end

